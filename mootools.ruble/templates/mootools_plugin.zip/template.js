/*
---
name: {name}

description: {description}

license: MIT-style

authors:
- ${TM_FULLNAME}

requires:
  - Core/Core

provides: [{provide}]

...
*/

(function($){



});

}(document.id));